HADAR LOGO KIT
==============

This kit contains the complete HADAR logo system in scalable vector format,
plus the layered source file.

Contents
--------
lockups/   — All 15 marks as individual SVGs (Hadar_Logo_Lockups-01 … -15):
             the canonical "Think Like a Founder" lockup, the supporting
             marks (horizontal, wordmark, crest, lettermark, reversed
             lettermark, radiant crest), and the simplified versions
             (solid ephod, crowned ephod, simplified rays, crown).
source/    — Hadar_Logo_Lockups.ai (layered Adobe Illustrator source).

Usage
-----
• Reach for the CANONICAL mark first — the stacked "Think Like a Founder"
  lockup. It is the single full application of the logo.
• Use the SUPPORTING marks when the canonical lockup or its tagline does not
  fit (horizontal layouts, navigation, ceremonial, tagline-less contexts).
• Use the SIMPLIFIED versions only for the most constrained applications —
  minimum sizing, embroidery, stamping, and single-color reproduction.
• Always scale from the SVG or .ai source. Never stretch, recolor, or
  redraw the marks. Maintain clear space of at least 1× the crest dimension.

Rights & provenance
-------------------
These marks are the HADAR brand identity. They are provided for authorized
HADAR brand use only and may not be redistributed or used to represent any
other organization.

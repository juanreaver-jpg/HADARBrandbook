HADAR Brand Fonts
=================

This bundle contains the three typefaces that make up the HADAR brand system.

1. Quadrat Serial  — Wordmark font
   Used exclusively for the HADAR wordmark and lockups. Not intended for body
   copy or general-purpose typesetting.

2. Libre Bodoni    — Display / Editorial (general usage)
   The serif voice of the brand. Use for headlines, pull quotes, and any
   editorial display setting. Weights included: 400 (Regular), 500 (Medium),
   700 (Bold) plus matching italics. Licensed under the SIL Open Font License
   1.1 (see Libre Bodoni/OFL.txt).

3. Inter           — Body / Functional (general usage)
   The sans companion. Use for body copy, UI, captions, and any functional
   text. Weights included: 400, 500, 600, 700 plus italics. Licensed under
   the SIL Open Font License 1.1 (see Inter/OFL.txt).

Pairing
-------
Libre Bodoni (serif) + Inter (sans) is the standard general-usage pairing.
Quadrat Serial is reserved for wordmark/identity treatments only.

Installation
------------
On macOS: double-click each font file and click "Install Font".
On Windows: right-click each font file and choose "Install".
On Linux: copy the font files into ~/.local/share/fonts/ and run
          `fc-cache -f -v`.
